# Dual-Band VCO Circuit Design for Drone Detection

## Overview

This document presents the design of a dual-band Voltage-Controlled Oscillator (VCO) circuit specifically optimized for drone detection applications. The VCO is designed to operate in both the 2.4 GHz and 5.8 GHz frequency bands, which are the primary communication frequencies used by commercial drones.

## Design Requirements

1. **Frequency Bands**:
   - 2.4 GHz band (2.4-2.5 GHz) for drone control signals
   - 5.8 GHz band (5.725-5.875 GHz) for drone video transmission

2. **Tuning Range**:
   - Minimum 80 MHz bandwidth to cover entire frequency hopping sequence
   - Continuous tuning capability within each band

3. **Phase Noise**:
   - Low phase noise for accurate signal detection
   - Target: < -110 dBc/Hz at 100 kHz offset for 2.4 GHz
   - Target: < -100 dBc/Hz at 100 kHz offset for 5.8 GHz

4. **Power Output**:
   - Sufficient output power for subsequent amplification stages
   - Minimum +5 dBm output power

5. **Tuning Voltage**:
   - 0-5V control voltage range
   - Linear voltage-to-frequency relationship

## Circuit Design Approach

Based on the research and available literature, we'll implement a dual-band LC-VCO design with band switching capability. The design will use a cross-coupled NMOS transistor pair for negative resistance generation and an LC tank circuit with switchable components for band selection.

### Circuit Topology

We'll use a Class-C VCO topology with a bias-controlled charge pump for improved phase noise performance, similar to the design referenced in the paper "Low Phase-Noise, 2.4 and 5.8 GHz Dual-Band Frequency Synthesizer with Class-C VCO and Bias-Controlled Charge Pump."

The key components of our VCO design include:

1. **LC Tank Circuit**:
   - High-Q inductor for resonance
   - Varactor diodes for frequency tuning
   - Switchable capacitor bank for band selection

2. **Active Circuit**:
   - Cross-coupled NMOS transistor pair for negative resistance
   - Class-C biasing for improved phase noise
   - Current source for biasing

3. **Band Selection**:
   - CMOS switches for band selection
   - Digital control interface

4. **Output Buffer**:
   - Buffer amplifier to isolate the VCO from load variations
   - Provides adequate output power

## Schematic Design

```
                    VDD
                     |
                     R
                     |
         +-----+-----+-----+-----+
         |     |           |     |
         C     L           L     C
         |     |           |     |
         |     +-----+-----+     |
         |           |           |
         |           |           |
    +----+----+      |      +----+----+
    |         |      |      |         |
    | M1      |      |      | M2      |
    |         |      |      |         |
    +----+----+      |      +----+----+
         |           |           |
         |           |           |
         +-----+-----+-----+-----+
               |     |     |
               |     C     |
               |     |     |
               |     |     |
               +--+--+--+--+
                  |     |
                  R     C_tune
                  |     |
                  +-----+
                    |
                   Vtune
```

### Component Selection

1. **Inductors (L)**:
   - High-Q inductors (Q > 20 at operating frequencies)
   - Value: ~1-2 nH for 5.8 GHz operation
   - Value: ~3-4 nH for 2.4 GHz operation

2. **Varactor Diodes (C_tune)**:
   - High-Q varactors with wide capacitance range
   - Capacitance range: 0.5-5 pF
   - Low series resistance

3. **Transistors (M1, M2)**:
   - NMOS transistors with low noise figure
   - Size optimized for negative resistance at both frequency bands
   - W/L ratio: ~100-200 μm/0.18 μm

4. **Switching Elements**:
   - Low-loss CMOS switches for band selection
   - PIN diodes for higher frequency applications

5. **Biasing Network**:
   - Current mirror for stable biasing
   - Class-C biasing for improved phase noise

## Band Switching Mechanism

The band switching mechanism will use a digitally controlled switch to modify the LC tank circuit:

1. **2.4 GHz Mode**:
   - Additional capacitors switched into the tank circuit
   - Larger effective inductance

2. **5.8 GHz Mode**:
   - Reduced capacitance in the tank circuit
   - Smaller effective inductance

## Output Buffer Design

The output buffer will use a common-source amplifier with inductive load to provide:

1. Isolation between the VCO and subsequent stages
2. Adequate output power (minimum +5 dBm)
3. 50Ω output impedance matching

## Performance Considerations

1. **Phase Noise Optimization**:
   - Class-C biasing for reduced noise
   - High-Q tank components
   - Optimized current consumption

2. **Frequency Stability**:
   - Temperature compensation network
   - Supply voltage regulation

3. **Tuning Linearity**:
   - Varactor biasing network design
   - Multiple varactors for improved linearity

## Integration with PLL

This VCO design will be integrated with a Phase-Locked Loop (PLL) in the next design stage to provide:

1. Stable frequency generation
2. Precise frequency control
3. Reduced phase noise through loop filtering

## Power Supply Requirements

1. Supply voltage: 3.3V
2. Current consumption: < 20 mA per band
3. Power-down mode for energy conservation

## Next Steps

1. Detailed component selection and sizing
2. SPICE simulation of the circuit
3. Layout considerations
4. Integration with PLL design
5. Performance verification against requirements
