# Phase-Locked Loop (PLL) Circuit Design for Drone Detection

## Overview

This document presents the design of a Phase-Locked Loop (PLL) circuit for frequency synthesis in a drone detection system. The PLL will work with the previously designed dual-band VCO to provide stable and precise frequency generation in the 2.4 GHz and 5.8 GHz bands used by commercial drones.

## Design Requirements

1. **Frequency Bands**:
   - 2.4 GHz band (2.4-2.5 GHz) for drone control signals
   - 5.8 GHz band (5.725-5.875 GHz) for drone video transmission

2. **Frequency Resolution**:
   - Fine resolution (< 100 kHz steps) for precise frequency control
   - Fast settling time (< 100 μs) for frequency hopping applications

3. **Phase Noise**:
   - Low in-band phase noise for accurate signal detection
   - Effective filtering of VCO phase noise

4. **Lock Range**:
   - Wide lock range to cover both frequency bands
   - Stable operation across temperature variations

5. **Reference Frequency**:
   - High-stability reference (10-100 MHz)
   - Low phase noise reference source

## PLL Architecture

We will implement an integer-N PLL architecture with the following components:

1. **Reference Oscillator**:
   - Temperature-compensated crystal oscillator (TCXO) or oven-controlled crystal oscillator (OCXO)
   - Frequency: 10 MHz
   - Stability: ±0.5 ppm or better

2. **Phase Frequency Detector (PFD)**:
   - Digital PFD with charge pump output
   - Low dead zone for improved phase noise performance

3. **Loop Filter**:
   - Third-order passive loop filter
   - Optimized for phase noise and settling time
   - Bandwidth: ~100 kHz for optimal noise performance

4. **Voltage-Controlled Oscillator (VCO)**:
   - Dual-band VCO as previously designed
   - 2.4 GHz and 5.8 GHz operation
   - Tuning voltage: 0-5V

5. **Frequency Dividers**:
   - Programmable divider for N-counter
   - Dual-modulus prescaler for high-frequency operation
   - Reference divider for flexible reference frequency

## PLL IC Selection

Based on the requirements, we'll use the ADF4351 or LMX2594 PLL synthesizer IC:

### ADF4351:
- Integrated VCO with 35 MHz to 4.4 GHz range
- Fractional-N and integer-N PLL
- Integrated prescalers and dividers
- Low phase noise performance
- SPI digital interface

### LMX2594:
- Wideband frequency synthesizer (10 MHz to 15 GHz)
- Ultra-low phase noise performance
- Integrated VCO and dividers
- Fast frequency hopping capability
- SPI digital interface

## Circuit Design

### Block Diagram

```
                  +----------+    +----------+    +----------+
                  |          |    |          |    |          |
Reference  +----->| Reference|    |  Phase   |    |  Loop    |
Oscillator        | Divider  +--->| Frequency+--->|  Filter  |
                  |          |    | Detector |    |          |
                  +----------+    +-----+----+    +-----+----+
                                        ^                |
                                        |                |
                                        |                v
                  +----------+    +-----+----+    +-----+----+
                  |          |    |          |    |          |
                  | Feedback |<---+    N     |<---+   VCO    +---> RF Output
                  | Divider  |    | Divider  |    |          |
                  |          |    |          |    |          |
                  +----------+    +----------+    +----------+
                                                       ^
                                                       |
                                                       |
                                                  Band Select
```

### Reference Path

1. **Reference Oscillator**:
   - 10 MHz TCXO or OCXO
   - Supply voltage: 3.3V
   - Output level: 3.3V CMOS or sine wave

2. **Reference Divider**:
   - Programmable divider (1-1023)
   - Allows flexible reference frequency selection

### Feedback Path

1. **VCO**:
   - Dual-band VCO as previously designed
   - 2.4 GHz and 5.8 GHz operation

2. **N Divider**:
   - Programmable divider (23-65535)
   - Dual-modulus prescaler for high-frequency division
   - Determines output frequency: Fout = Fref × (N/R)

### Phase Detector and Loop Filter

1. **Phase Frequency Detector**:
   - Digital PFD with charge pump
   - Programmable charge pump current (0.31-5 mA)
   - Low phase noise contribution

2. **Loop Filter**:
   - Third-order passive filter
   - Components calculated for optimal loop bandwidth and phase margin
   - Bandwidth: ~100 kHz for 2.4 GHz operation
   - Bandwidth: ~200 kHz for 5.8 GHz operation

### Loop Filter Design

For a third-order passive loop filter:

```
                    C1
             +------||-------+
             |               |
Charge Pump  |      R2       |  To VCO
Output o-----+------WWW------+-----o
             |               |
             |      C2       |
             +------||-------+
             |               |
             |      C3       |
             +------||-------+
             |               |
             +-------GND-----+
```

Component values for 100 kHz loop bandwidth:
- R2 = 1.0 kΩ
- C1 = 3.3 nF
- C2 = 220 pF
- C3 = 22 pF

These values will be optimized based on:
- Loop bandwidth requirements
- Phase margin (target: 45-55 degrees)
- Settling time requirements
- VCO gain (KVCO)
- Charge pump current

### Digital Control Interface

The PLL will be controlled via an SPI interface with the following signals:
- SCLK: Serial clock
- SDI: Serial data input
- LE: Latch enable
- CE: Chip enable

## Frequency Plan

### 2.4 GHz Band Operation:
- Reference frequency: 10 MHz
- Reference divider (R): 1
- Comparison frequency: 10 MHz
- N divider: 240-250 (for 2.4-2.5 GHz)
- Channel spacing: 100 kHz

### 5.8 GHz Band Operation:
- Reference frequency: 10 MHz
- Reference divider (R): 1
- Comparison frequency: 10 MHz
- N divider: 572-588 (for 5.72-5.88 GHz)
- Channel spacing: 100 kHz

## Performance Considerations

1. **Phase Noise Optimization**:
   - Optimize loop bandwidth for best noise performance
   - Use low-noise reference oscillator
   - Minimize noise contribution from charge pump and dividers

2. **Spurious Performance**:
   - Careful layout to minimize coupling
   - Optimize charge pump current to minimize reference spurs
   - Proper power supply filtering

3. **Lock Time**:
   - Optimize loop bandwidth for required settling time
   - Use fast PFD and charge pump
   - Consider adaptive loop bandwidth for faster lock

## Power Supply Requirements

1. **Supply Voltage**:
   - 3.3V for digital circuits
   - 5V for analog circuits (if required)

2. **Power Consumption**:
   - < 100 mA total current consumption
   - Power-down modes for energy conservation

## PCB Layout Considerations

1. **Critical Areas**:
   - Separate analog and digital grounds
   - Short, direct connections for loop filter
   - Proper RF routing and impedance control
   - Adequate isolation between RF sections

2. **Component Placement**:
   - Keep loop filter components close to PLL IC
   - Minimize trace length for high-frequency signals
   - Proper bypass capacitor placement

## Integration with System

The PLL will interface with:
1. The dual-band VCO for frequency generation
2. A microcontroller for programming and control
3. The DDS for precise frequency modulation
4. The RF fingerprinting module for signal analysis

## Next Steps

1. Detailed component selection
2. Loop filter optimization using PLL design software
3. Schematic capture
4. PCB layout
5. Integration with VCO design
6. Performance verification against requirements
