# Crystal Oscillator Design for Drone Detection Reference Stability

## Overview

This document presents the design of a high-stability crystal oscillator circuit to serve as the reference frequency source for the drone detection system. The crystal oscillator will provide the stable reference needed by the PLL and DDS circuits previously designed, ensuring accurate frequency generation and low phase noise performance critical for drone detection applications.

## Design Requirements

1. **Frequency Stability**:
   - Short-term stability: < 0.1 ppm
   - Long-term aging: < 1 ppm/year
   - Temperature stability: < 0.5 ppm over operating range

2. **Phase Noise Performance**:
   - < -130 dBc/Hz at 100 Hz offset
   - < -150 dBc/Hz at 1 kHz offset
   - < -160 dBc/Hz at 10 kHz offset

3. **Reference Frequency**:
   - Primary frequency: 10 MHz (industry standard)
   - Optional secondary frequency: 100 MHz for higher performance

4. **Environmental Performance**:
   - Operating temperature range: -40°C to +85°C
   - Vibration resistance for mobile deployment
   - Low sensitivity to power supply variations

5. **Output Characteristics**:
   - Multiple outputs for PLL, DDS, and other system components
   - Output level: 3.3V CMOS and/or sine wave options
   - Low harmonic content for sine wave output

## Oscillator Type Selection

Based on the requirements for drone detection applications, we'll implement an Oven-Controlled Crystal Oscillator (OCXO) design for maximum stability:

### OCXO Advantages:
- Highest frequency stability (typically 0.001 to 0.1 ppm)
- Excellent temperature stability through oven temperature control
- Superior phase noise performance
- Reduced sensitivity to environmental variations

### Alternative Options:
- **TCXO (Temperature-Compensated Crystal Oscillator)**:
  - Good stability (typically 0.1 to 1 ppm)
  - Lower power consumption than OCXO
  - Smaller size and lower cost
  - May be suitable for less demanding applications

- **MEMS-Based Oscillator**:
  - Better shock and vibration resistance
  - Smaller size
  - Lower power consumption
  - Generally higher phase noise than crystal-based solutions

## Circuit Design

### Block Diagram

```
                +----------+    +----------+    +----------+
                |          |    |          |    |          |
                |Temperature    |  Crystal |    | Oscillator|
                | Control  +--->|  Oven    |    |  Circuit  |
                | Circuit  |    |          |    |          |
                +----------+    +-----+----+    +-----+----+
                                      |               |
                                      v               v
                                +-----+---------------+----+
                                |                          |
                                |      AT-Cut Crystal      |
                                |                          |
                                +--------------------------+
                                            |
                                            v
                +----------+    +----------+    +----------+
                |          |    |          |    |          |
                |  Buffer  |    |  Output  |    |  Power   |
                | Amplifier+--->| Splitter +--->|  Supply  |
                |          |    |          |    |Regulation|
                +-----+----+    +----------+    +----------+
                      |                               ^
                      |                               |
                      v                               |
                Multiple                          DC Input
                Outputs
```

### Crystal Selection

1. **Crystal Type**:
   - AT-cut quartz crystal for 10 MHz operation
   - SC-cut for higher performance applications
   - 3rd or 5th overtone for higher frequencies

2. **Crystal Parameters**:
   - Frequency: 10 MHz
   - Load capacitance: 18-20 pF (matched to circuit)
   - Equivalent series resistance (ESR): < 50 Ω
   - Q factor: > 1,000,000 for high performance
   - Aging rate: < 1 ppm/year

### Oscillator Circuit

We'll implement a Colpitts oscillator topology for optimal performance:

```
                    VDD
                     |
                     R1
                     |
                     +----+
                     |    |
                     C3   L1
                     |    |
                     |    +----+
                     |         |
                +----+----+    |
                |    |    |    |
                |    C1   |    |
                |    |    |    |
                +----+----+----+
                |    |         |
                Q1   XTAL      |
                |    |         |
                +----+----+----+
                     |    |
                     C2   R2
                     |    |
                     +----+
                     |
                    GND
```

1. **Active Device**:
   - Low-noise transistor or FET (e.g., 2N3904, J310)
   - Alternatively, specialized oscillator IC (e.g., LTC6930)

2. **Passive Components**:
   - C1, C2: Matched capacitors for frequency determination
   - C3: Coupling capacitor
   - R1: Biasing resistor
   - R2: Feedback resistor
   - L1: RF choke (optional)

### Temperature Control

For the OCXO design:

1. **Oven Design**:
   - Insulated enclosure around crystal and oscillator circuit
   - Heating element (resistor or transistor)
   - Temperature sensor (thermistor or IC-based)
   - Set point typically 75-85°C (above ambient temperature range)

2. **Temperature Controller**:
   - Proportional-Integral (PI) control loop
   - Precision voltage reference
   - Op-amp based comparator and driver
   - Low-noise power supply for heater

### Buffer and Output Stage

1. **Buffer Amplifier**:
   - Isolation between oscillator and load
   - Low phase noise contribution
   - High input impedance, low output impedance

2. **Output Options**:
   - CMOS output (3.3V) for digital circuits
   - Sine wave output (1Vpp into 50Ω) for RF applications
   - Multiple buffered outputs for different system components

3. **Output Distribution**:
   - Power splitter for multiple outputs
   - Impedance matching for each output
   - Optional frequency multiplication for higher frequency outputs

### Power Supply

1. **Voltage Regulation**:
   - Low-noise linear regulators
   - Multiple stages of filtering
   - Separate supplies for oscillator, buffer, and oven circuits

2. **Power Requirements**:
   - Input voltage: 12V DC
   - Oscillator circuit: 5V, < 50 mA
   - Oven circuit: 12V, 100-500 mA (higher during warm-up)
   - Total power: 1-5W (depending on ambient temperature)

## Performance Optimization

1. **Phase Noise Reduction**:
   - Optimize Q of the resonator circuit
   - Minimize noise from active devices
   - Proper impedance matching
   - Careful power supply filtering

2. **Frequency Stability Enhancement**:
   - Precise temperature control
   - Aging compensation (optional)
   - Vibration isolation
   - EMI/RFI shielding

3. **Startup Behavior**:
   - Fast oven warm-up circuit
   - Oscillator enable control
   - Status indication output

## PCB Layout Considerations

1. **Critical Areas**:
   - Separate ground planes for analog and digital sections
   - Short, direct connections for crystal
   - Thermal isolation for oven section
   - EMI/RFI shielding

2. **Component Placement**:
   - Crystal and oscillator components within oven boundary
   - Temperature sensor in close thermal contact with crystal
   - Buffer amplifier outside oven but close to oscillator
   - Power regulation components away from sensitive areas

## Integration with System

The crystal oscillator will interface with:
1. The PLL circuit for frequency synthesis
2. The DDS circuit for precise waveform generation
3. Other system timing components requiring reference signals

## Performance Verification

1. **Frequency Stability Testing**:
   - Allan deviation measurement
   - Temperature cycling
   - Long-term aging test

2. **Phase Noise Testing**:
   - Phase noise analyzer measurement
   - Spectrum analyzer with phase noise utility
   - Reference comparison method

3. **Output Characterization**:
   - Level and waveform verification
   - Harmonic content measurement
   - Load sensitivity testing

## Next Steps

1. Detailed component selection
2. Schematic capture
3. PCB layout with thermal considerations
4. Prototype construction and testing
5. Integration with PLL and DDS designs
6. System-level performance verification
